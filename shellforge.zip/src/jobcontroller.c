#define _POSIX_C_SOURCE 200809L
#include <signal.h>
#include <sys/wait.h>
#include <unistd.h>

#include "job.h"

void jobcontroller_init(void)
{
    jobs_init();
}

void jobcontroller_set_process_group(pid_t pid, pid_t pgid)
{
    if (setpgid(pid, pgid) == -1)
    {
        /* Process group may already have been created */
    }
}

void jobcontroller_stop(pid_t pgid)
{
    if (kill(-pgid, SIGSTOP) == 0)
        job_stop(pgid);
}

void jobcontroller_continue(pid_t pgid)
{
    if (kill(-pgid, SIGCONT) == 0)
        job_continue(pgid);
}

void jobcontroller_wait_foreground(pid_t pgid)
{
    int status;

    while (waitpid(-pgid, &status, WUNTRACED) > 0)
    {
        if (WIFSTOPPED(status))
        {
            job_stop(pgid);
            return;
        }

        if (WIFEXITED(status) || WIFSIGNALED(status))
            break;
    }

    job_done(pgid);
}
