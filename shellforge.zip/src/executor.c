#define _POSIX_C_SOURCE 200809L

#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <fcntl.h>
#include <signal.h>
#include <errno.h>
#include <string.h>

#include "executor.h"
#include "builtin.h"
#include "job.h"
#include "jobcontroller.h"
static void give_terminal_to(pid_t pgid)
{
    tcsetpgrp(STDIN_FILENO, pgid);
}

static void take_terminal_back(void)
{
    tcsetpgrp(STDIN_FILENO, getpgrp());
}

/* ---------------------------------------------------------
   SIGCHLD handler
   --------------------------------------------------------- */

static void reap_background_processes(int sig)
{
    int status;
    pid_t pid;

    (void)sig;

    while ((pid = waitpid(-1, &status, WNOHANG)) > 0)
    {
        job_t *job = job_find_by_pgid(pid);

        if (job != NULL)
        {
            if (WIFEXITED(status) || WIFSIGNALED(status))
            {
                job_done(pid);
            }
        }
    }
}


/* ---------------------------------------------------------
   Setup SIGCHLD
   --------------------------------------------------------- */

static void setup_sigchld(void)
{
    struct sigaction sa;

    memset(&sa, 0, sizeof(sa));

    sa.sa_handler = reap_background_processes;
    sigemptyset(&sa.sa_mask);

    sa.sa_flags = SA_RESTART | SA_NOCLDSTOP;

    sigaction(SIGCHLD, &sa, NULL);
}


/* ---------------------------------------------------------
   Build command string
   --------------------------------------------------------- */

static void build_command_string(command_t *cmd,
                                 char *buffer,
                                 size_t size)
{
    size_t i;
    size_t used = 0;

    buffer[0] = '\0';

    for (i = 0; i < cmd->argc; i++)
    {
        if (i > 0)
        {
            if (used + 1 >= size)
                break;

            buffer[used++] = ' ';
            buffer[used] = '\0';
        }

        if (used + strlen(cmd->argv[i]) >= size)
            break;

        strcpy(buffer + used, cmd->argv[i]);
        used += strlen(cmd->argv[i]);
    }
}


/* ---------------------------------------------------------
   Build pipeline string
   --------------------------------------------------------- */

static void build_pipeline_string(pipeline_t *pipeline,
                                  char *buffer,
                                  size_t size)
{
    size_t i;
    size_t used = 0;

    buffer[0] = '\0';

    for (i = 0; i < pipeline->command_count; i++)
    {
        char command_text[MAX_JOB_COMMAND];

        build_command_string(&pipeline->commands[i],
                             command_text,
                             sizeof(command_text));

        if (i > 0)
        {
            if (used + 3 >= size)
                break;

            strcpy(buffer + used, " | ");
            used += 3;
        }

        if (used + strlen(command_text) >= size)
            break;

        strcpy(buffer + used, command_text);
        used += strlen(command_text);
    }
}


/* ---------------------------------------------------------
   Execute single command
   --------------------------------------------------------- */

int execute_command(command_t *cmd)
{
    pid_t pid;
    int status;
    int background;
    char command_text[MAX_JOB_COMMAND];

    if (cmd == NULL || cmd->argc == 0)
        return 0;

    setup_sigchld();

    /* jobs, fg and bg must run in parent */
    if (is_job_builtin(cmd))
    {
        return execute_builtin(cmd);
    }

    background = cmd->background;

    build_command_string(cmd,
                         command_text,
                         sizeof(command_text));

    pid = fork();

    if (pid < 0)
    {
        perror("fork");
        return -1;
    }

    /* -----------------------------------------------------
       Child process
       ----------------------------------------------------- */

    if (pid == 0)
    {
        int fd;

        /* Create process group */
        setpgid(0, 0);

        /* Background process gets /dev/null as stdin */
        if (background)
        {
            fd = open("/dev/null", O_RDONLY);

            if (fd >= 0)
            {
                dup2(fd, STDIN_FILENO);
                close(fd);
            }
        }

        /* Input redirection */
        if (cmd->input[0] != '\0')
        {
            fd = open(cmd->input, O_RDONLY);

            if (fd < 0)
            {
                perror("open input");
                exit(EXIT_FAILURE);
            }

            dup2(fd, STDIN_FILENO);
            close(fd);
        }

        /* Output redirection */
        if (cmd->output[0] != '\0')
        {
            fd = open(cmd->output,
                      O_WRONLY | O_CREAT | O_TRUNC,
                      0644);

            if (fd < 0)
            {
                perror("open output");
                exit(EXIT_FAILURE);
            }

            dup2(fd, STDOUT_FILENO);
            close(fd);
        }

        /* Execute builtin inside child */
        if (is_builtin(cmd))
        {
            exit(execute_builtin(cmd));
        }

        /* Execute normal command */
        execvp(cmd->argv[0], cmd->argv);

        perror(cmd->argv[0]);
        exit(EXIT_FAILURE);
    }


    /* -----------------------------------------------------
       Parent process
       ----------------------------------------------------- */

    setpgid(pid, pid);
if (!background)
{
    give_terminal_to(pid);
}

    /* -----------------------------------------------------
       Background command
       ----------------------------------------------------- */

    if (background)
    {
        int job_id;

        job_id = job_add(pid,
                         command_text,
                         JOB_RUNNING);

        if (job_id > 0)
        {
            printf("[%d] Running %s\n",
                   job_id,
                   command_text);
        }

        return 0;
    }


    /* -----------------------------------------------------
       Foreground command
       ----------------------------------------------------- */
give_terminal_to(pid);
    while (1)
    {
        pid_t result;

        result = waitpid(pid,
                         &status,
                         WUNTRACED);

        if (result == -1)
        {
            if (errno == EINTR)
                continue;

            perror("waitpid");
            return -1;
        }

        break;
    }


    /* -----------------------------------------------------
       Foreground process stopped
       ----------------------------------------------------- */

    if (WIFSTOPPED(status))
    {
        int job_id;

        job_id = job_add(pid,
                         command_text,
                         JOB_STOPPED);

        if (job_id > 0)
        {
            printf("[%d] Stopped %s\n",
                   job_id,
                   command_text);
        }
  take_terminal_back();
        return 0;
    }


    /* -----------------------------------------------------
       Process terminated normally
       ----------------------------------------------------- */

    if (WIFEXITED(status))
    {
 take_terminal_back();
        return WEXITSTATUS(status);
    }


    /* -----------------------------------------------------
       Process terminated by signal
       ----------------------------------------------------- */

    if (WIFSIGNALED(status))
    {
        fprintf(stderr,
                "Process terminated by signal %d\n",
                WTERMSIG(status));
 take_terminal_back();
        return -1;
    }

    return 0;
}


/* ---------------------------------------------------------
   Execute pipeline
   --------------------------------------------------------- */

int execute_pipeline(pipeline_t *pipeline)
{
    int pipes[2][2];
    pid_t pids[32];
    pid_t pgid = 0;

    int i;
    int status;
    int background;

    char command_text[MAX_JOB_COMMAND];

    if (pipeline == NULL || pipeline->command_count == 0)
        return 0;

    setup_sigchld();

    background = pipeline->commands[pipeline->command_count - 1].background;

    build_pipeline_string(pipeline,
                          command_text,
                          sizeof(command_text));


    /* -----------------------------------------------------
       Create pipes
       ----------------------------------------------------- */

    for (i = 0; i < pipeline->command_count - 1; i++)
    {
        if (pipe(pipes[i]) == -1)
        {
            perror("pipe");
            return -1;
        }
    }


    /* -----------------------------------------------------
       Create child processes
       ----------------------------------------------------- */

    for (i = 0; i < pipeline->command_count; i++)
    {
        pid_t pid;

        pid = fork();

        if (pid < 0)
        {
            perror("fork");
            return -1;
        }


        /* -------------------------------------------------
           Child
           ------------------------------------------------- */

        if (pid == 0)
        {
            int fd;
 signal(SIGTSTP, SIG_DFL);
    signal(SIGTTIN, SIG_DFL);
    signal(SIGTTOU, SIG_DFL);
    signal(SIGINT, SIG_DFL);
    signal(SIGQUIT, SIG_DFL);

    setpgid(0, 0);
            if (i == 0)
            {
                setpgid(0, 0);
            }
            else
            {
                setpgid(0, pgid);
            }


            /* Input from previous pipe */
            if (i > 0)
            {
                dup2(pipes[i - 1][0],
                     STDIN_FILENO);
            }


            /* Output to next pipe */
            if (i < pipeline->command_count - 1)
            {
                dup2(pipes[i][1],
                     STDOUT_FILENO);
            }


            /* Background pipeline stdin */
            if (background && i == 0)
            {
                fd = open("/dev/null", O_RDONLY);

                if (fd >= 0)
                {
                    dup2(fd, STDIN_FILENO);
                    close(fd);
                }
            }


            /* Input redirection */
            if (pipeline->commands[i].input[0] != '\0')
            {
                fd = open(pipeline->commands[i].input,
                          O_RDONLY);

                if (fd < 0)
                {
                    perror("open input");
                    exit(EXIT_FAILURE);
                }

                dup2(fd, STDIN_FILENO);
                close(fd);
            }


            /* Output redirection */
            if (pipeline->commands[i].output[0] != '\0')
            {
                fd = open(pipeline->commands[i].output,
                          O_WRONLY | O_CREAT | O_TRUNC,
                          0644);

                if (fd < 0)
                {
                    perror("open output");
                    exit(EXIT_FAILURE);
                }

                dup2(fd, STDOUT_FILENO);
                close(fd);
            }


            /* Close all pipes */
            for (int j = 0;
                 j < pipeline->command_count - 1;
                 j++)
            {
                close(pipes[j][0]);
                close(pipes[j][1]);
            }


            /* Builtin */
            if (is_builtin(&pipeline->commands[i]))
            {
                exit(execute_builtin(
                    &pipeline->commands[i]));
            }


            /* External command */
            execvp(pipeline->commands[i].argv[0],
                   pipeline->commands[i].argv);

            perror(pipeline->commands[i].argv[0]);
            exit(EXIT_FAILURE);
        }


        /* -------------------------------------------------
           Parent
           ------------------------------------------------- */

        pids[i] = pid;

        if (i == 0)
        {
            pgid = pid;
        }

        setpgid(pid, pgid);
    }


    /* -----------------------------------------------------
       Parent closes pipes
       ----------------------------------------------------- */

    for (i = 0; i < pipeline->command_count - 1; i++)
    {
        close(pipes[i][0]);
        close(pipes[i][1]);
    }


    /* -----------------------------------------------------
       Background pipeline
       ----------------------------------------------------- */

    if (background)
    {
        int job_id;

        job_id = job_add(pgid,
                         command_text,
                         JOB_RUNNING);

        if (job_id > 0)
        {
            printf("[%d] Running %s\n",
                   job_id,
                   command_text);
        }

        return 0;
    }


    /* -----------------------------------------------------
       Foreground pipeline
       ----------------------------------------------------- */

    for (i = 0; i < pipeline->command_count; i++)
    {
        while (1)
        {
            pid_t result;

            result = waitpid(pids[i],
                             &status,
                             WUNTRACED);

            if (result == -1)
            {
                if (errno == EINTR)
                    continue;

                perror("waitpid");
                break;
            }

            break;
        }


        /* Pipeline stopped */
        if (WIFSTOPPED(status))
        {
            int job_id;

            job_id = job_add(pgid,
                             command_text,
                             JOB_STOPPED);

            if (job_id > 0)
            {
                printf("[%d] Stopped %s\n",
                       job_id,
                       command_text);
            }

            break;
        }
    }

    return 0;
}
